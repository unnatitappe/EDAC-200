public class InvertedNumberPyramid
private static void printPattern7(int rows) {
	// for loop for the rows
	for (int i = rows; i >= 1; i--) {
		// white spaces in the front of the numbers
		int numberOfWhiteSpaces = rows - i;

		//print leading white spaces
		printString(" ", numberOfWhiteSpaces);

		//print character
		printString(i+" ", i);

		//move to next line
		System.out.println("");
	}
}