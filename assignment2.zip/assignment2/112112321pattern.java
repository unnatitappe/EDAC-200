public class 112112321pattern
private static void printPattern4(int rows) {
	// for loop for the rows
	for (int i = 1; i <= rows; i++) {
		// white spaces in the front of the numbers
		int numberOfWhiteSpaces = (rows-i)*2;

		//print leading white spaces
		printString(" ", numberOfWhiteSpaces);

		//print numbers
		for(int x=1; x0; j--) {
			System.out.print(j+" ");
		}

		//move to next line
		System.out.println("");
	}
}